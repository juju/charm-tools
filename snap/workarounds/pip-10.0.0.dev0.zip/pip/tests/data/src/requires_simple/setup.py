from setuptools import find_packages, setup

setup(name='requires_simple',
      version='0.1',
      install_requires=['simple==1.0']
      )
