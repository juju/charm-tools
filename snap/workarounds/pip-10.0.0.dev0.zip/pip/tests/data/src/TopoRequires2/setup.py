from setuptools import setup

setup(
    name='TopoRequires2',
    version='0.0.1',
    packages=['toporequires2'],
    install_requires=['TopoRequires'],
)
